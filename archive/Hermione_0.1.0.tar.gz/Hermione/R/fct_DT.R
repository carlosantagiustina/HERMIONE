#' DT
#'
#' @description A fct function
#'
#' @return a datatable (from DT package) object that can be displayed in the UI of a Shiny APP
#'
#' @noRd
